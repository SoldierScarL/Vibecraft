import {
  WebGPURenderer,
  Scene,
  PerspectiveCamera,
  Clock,
  Color,
  FogExp2,
  Mesh,
  IcosahedronGeometry,
  SphereGeometry,
  BufferAttribute,
  MeshStandardNodeMaterial,
  DirectionalLight,
  AmbientLight,
  HemisphereLight,
  ACESFilmicToneMapping,
  Vector3,
} from 'three/webgpu';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { mergeVertices } from 'three/addons/utils/BufferGeometryUtils.js';
import { Water, PRESET_NAMES, PRESETS, QUALITY_NAMES, createOceanFloor } from '../lib/index.js';

const statusEl = document.getElementById('status');
const fpsEl = document.getElementById('fps');
const presetBar = document.getElementById('presets');
const qualityBar = document.getElementById('quality');
const diveBtn = document.getElementById('dive');
const backendEl = document.getElementById('backend');

const EMBED = new URLSearchParams(location.search).has('embed');
const EMBED_PRESET = new URLSearchParams(location.search).get('preset');

let renderer, scene, camera, controls, water, floor, buoyancy, clock, sun;
let underwater = false;
let lastSubmerged = false;
let autoQuality = true; // auto-degrade until the user picks a level
let slowStreak = 0;
const buoys = [];

const FLOOR_OPTS = { size: 2600, segments: 220, deepDepth: 28, beachHeight: 8, shoreAxis: 'x' };

async function init() {
  renderer = new WebGPURenderer({ antialias: true });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.setSize(window.innerWidth, window.innerHeight);
  renderer.toneMapping = ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.0;
  document.getElementById('app').appendChild(renderer.domElement);

  try {
    await renderer.init();
  } catch (err) {
    statusEl.textContent = 'Renderer init failed: ' + err.message;
    throw err;
  }
  const isWebGPU = !!renderer.backend?.isWebGPUBackend;
  backendEl.textContent = isWebGPU ? 'WebGPU' : 'WebGL2';

  scene = new Scene();

  camera = new PerspectiveCamera(55, window.innerWidth / window.innerHeight, 0.1, 14000);
  camera.position.set(120, 30, 215);

  controls = new OrbitControls(camera, renderer.domElement);
  controls.target.set(140, -2, 30);
  controls.enableDamping = true;
  controls.dampingFactor = 0.06;
  controls.maxPolarAngle = Math.PI * 0.92;
  controls.minDistance = 6;
  controls.maxDistance = 900;

  sun = new DirectionalLight(0xfff4e0, 2.4);
  sun.position.set(120, 200, -80);
  scene.add(sun);
  scene.add(new HemisphereLight(0xcfe8f7, 0x7a6f54, 1.15));
  scene.add(new AmbientLight(0x6b8088, 0.55));

  // WebGPU is the target; the WebGL2 fallback starts low and the lighter
  // shader paths (no detail normals / sparkle / turbulent foam / clouds) are
  // compiled out at that level so it stays interactive.
  const startPreset = EMBED_PRESET || 'tropical';
  const startQuality = EMBED ? 'medium' : isWebGPU ? 'high' : 'low';
  water = new Water({ preset: startPreset, quality: startQuality, extent: 8000 });
  scene.add(water.object);

  buildFloor();
  buildScenery();

  buoyancy = water.createBuoyancy();
  addBuoys();

  applyPresetLook();
  clock = new Clock();
  buildPresetButtons();
  buildQualityButtons();

  window.addEventListener('resize', onResize);
  diveBtn.addEventListener('click', toggleDive);

  if (EMBED) {
    document.body.classList.add('embed');
    controls.enabled = false;
  }

  statusEl.style.display = 'none';
  renderer.setAnimationLoop(animate);
  window.__demo = { renderer, scene, camera, water, floor, buoyancy, animate, toggleDive };
}

function buildFloor() {
  floor = createOceanFloor({
    ...FLOOR_OPTS,
    timeNode: water.timeNode,
    preset: water.config.floor,
  });
  scene.add(floor.mesh);
}

// Approximate the seabed height profile (mirrors oceanFloor's sculpting) so we
// can sit rocks on the bottom.
function floorHeightAt(x) {
  const half = FLOOR_OPTS.size / 2;
  const along = x / half;
  const t = (along + 1) / 2;
  const slope = -FLOOR_OPTS.deepDepth + (FLOOR_OPTS.deepDepth + FLOOR_OPTS.beachHeight) * Math.pow(t, 1.7);
  return slope;
}

// --- procedural 3-D value noise for organic rock shapes -------------------
function hash3(x, y, z) {
  const n = Math.sin(x * 127.1 + y * 311.7 + z * 74.7) * 43758.5453;
  return n - Math.floor(n);
}
function lerp(a, b, t) {
  return a + (b - a) * t;
}
function noise3(x, y, z) {
  const xi = Math.floor(x), yi = Math.floor(y), zi = Math.floor(z);
  const xf = x - xi, yf = y - yi, zf = z - zi;
  const u = xf * xf * (3 - 2 * xf), v = yf * yf * (3 - 2 * yf), w = zf * zf * (3 - 2 * zf);
  const c = (i, j, k) => hash3(xi + i, yi + j, zi + k);
  return lerp(
    lerp(lerp(c(0, 0, 0), c(1, 0, 0), u), lerp(c(0, 1, 0), c(1, 1, 0), u), v),
    lerp(lerp(c(0, 0, 1), c(1, 0, 1), u), lerp(c(0, 1, 1), c(1, 1, 1), u), v),
    w
  );
}
function fbm3(x, y, z) {
  let a = 0, amp = 0.5, f = 1;
  for (let o = 0; o < 5; o++) {
    a += amp * (noise3(x * f, y * f, z * f) * 2 - 1);
    f *= 2;
    amp *= 0.5;
  }
  return a;
}

// A smooth, organically-lumpy boulder with baked vertex colours + AO.
function makeRock(radius, seed = 0, detail = 6) {
  // IcosahedronGeometry is non-indexed → weld vertices so normals smooth
  // across faces (otherwise it renders flat-shaded / faceted).
  const geo = mergeVertices(new IcosahedronGeometry(radius, detail));
  const p = geo.attributes.position;
  const v = new Vector3();
  const ox = seed * 13.1, oy = seed * 7.7, oz = seed * 3.3;
  const sx = 0.85 + Math.random() * 0.45, sy = 0.62 + Math.random() * 0.3, sz = 0.85 + Math.random() * 0.45;

  const colors = new Float32Array(p.count * 3);
  const dark = new Color(0x2f2a21), light = new Color(0x8c7e63), moss = new Color(0x55603a), wet = new Color(0x1c1813);
  const col = new Color();

  for (let i = 0; i < p.count; i++) {
    v.fromBufferAttribute(p, i).normalize();
    const nx = v.x, ny = v.y, nz = v.z;
    // Multi-octave radial displacement. A ridged octave (1−|noise|) carves
    // sharp crests/cracks so the silhouette reads as stone, not a smooth lump.
    const big = fbm3(nx * 1.1 + ox, ny * 1.1 + oy, nz * 1.1 + oz);
    const ridge = 1 - Math.abs(fbm3(nx * 2.4 + ox, ny * 2.4 + oy, nz * 2.4 + oz));
    const med = fbm3(nx * 3.2 + ox, ny * 3.2 + oy, nz * 3.2 + oz) * 0.5;
    const fine = fbm3(nx * 7.0 + ox, ny * 7.0 + oy, nz * 7.0 + oz) * 0.28;
    const micro = fbm3(nx * 15.0 + ox, ny * 15.0 + oy, nz * 15.0 + oz) * 0.11;
    const detailSum = big * 0.34 + (ridge - 0.5) * 0.34 + med + fine + micro;
    const disp = 1 + detailSum;
    v.set(nx * sx, ny * sy, nz * sz).multiplyScalar(radius * disp);
    p.setXYZ(i, v.x, v.y, v.z);

    // Albedo: mottled stone, crevice AO, sun-bleached/mossy tops, wet base.
    col.copy(dark).lerp(light, fine * 1.2 + big * 0.4 + 0.45);
    const ao = Math.min(1, Math.max(0, 0.5 - detailSum * 1.7)); // concave → darker
    col.multiplyScalar(1 - ao * 0.55);
    if (ny > 0.15) col.lerp(moss, Math.min(0.35, (ny - 0.15) * 0.5 * (fine + 0.5))); // tops
    const wetF = Math.min(0.75, Math.max(0, (0.0 - ny) * 1.6) * 0.8);
    col.lerp(wet, wetF);
    colors[i * 3] = col.r;
    colors[i * 3 + 1] = col.g;
    colors[i * 3 + 2] = col.b;
  }
  geo.setAttribute('color', new BufferAttribute(colors, 3));
  geo.computeVertexNormals(); // smooth, because the geometry is now welded

  const mat = new MeshStandardNodeMaterial({ vertexColors: true, roughness: 0.88, metalness: 0.0 });
  return new Mesh(geo, mat);
}

function buildScenery() {
  // Rocks clustered around the waterline (x ≈ where the seabed crosses y=0).
  const spots = [
    [150, 60, 1.2], [240, -40, 0.7], [120, -120, 0.85],
    [300, 120, 0.6], [70, 150, 0.9], [210, 200, 0.7],
    [40, -180, 1.0], [330, -150, 0.5], [-30, 40, 1.15],
  ];
  spots.forEach(([x, z, s], i) => {
    const r = makeRock(18 * s, i + 1);
    const baseY = floorHeightAt(x);
    r.position.set(x, baseY + 7 * s, z);
    r.rotation.set(Math.random() * 0.4, Math.random() * 6, Math.random() * 0.4);
    scene.add(r);
  });
}

function addBuoys() {
  const buoyMat = new MeshStandardNodeMaterial({ color: 0xff5533, roughness: 0.55, emissive: 0x200800 });
  for (let i = 0; i < 4; i++) {
    const b = new Mesh(new SphereGeometry(3.2, 24, 18), buoyMat);
    b.position.set(-120 - i * 60, 0, -30 + i * 55);
    b.castShadow = true;
    scene.add(b);
    buoyancy.add(b, { offset: 1.4, damping: 5, alignment: 1 });
    buoys.push(b);
  }
}

function buildPresetButtons() {
  presetBar.innerHTML = '';
  for (const name of PRESET_NAMES) {
    const btn = document.createElement('button');
    btn.textContent = PRESETS[name].name;
    btn.dataset.preset = name;
    if (name === 'tropical') btn.classList.add('active');
    btn.addEventListener('click', () => {
      water.setPreset(name);
      rebuildFloor();
      applyPresetLook();
      document.querySelectorAll('#presets button').forEach((b) => b.classList.remove('active'));
      btn.classList.add('active');
    });
    presetBar.appendChild(btn);
  }
}

function buildQualityButtons() {
  if (!qualityBar) return;
  qualityBar.innerHTML = '<span class="lbl">Quality</span>';
  for (const name of QUALITY_NAMES) {
    const btn = document.createElement('button');
    btn.textContent = name[0].toUpperCase() + name.slice(1);
    btn.dataset.quality = name;
    if (name === water.quality) btn.classList.add('active');
    btn.addEventListener('click', () => {
      autoQuality = false; // respect the user's choice from now on
      water.setQuality(name);
      setActiveQualityButton(name);
    });
    qualityBar.appendChild(btn);
  }
}

function setActiveQualityButton(name) {
  document.querySelectorAll('#quality button').forEach((b) =>
    b.classList.toggle('active', b.dataset.quality === name)
  );
}

function rebuildFloor() {
  scene.remove(floor.mesh);
  floor.geometry.dispose();
  floor.material.dispose();
  buildFloor();
}

function applyPresetLook() {
  const cfg = water.config;
  const d = water.skyUniforms.sunDirection.value;
  sun.position.copy(d).multiplyScalar(300);
  sun.color.set(cfg.sun.color);
  sun.intensity = 1.6 + cfg.sun.intensity;
  if (!underwater) {
    scene.background = new Color(cfg.sky.horizonColor);
    scene.fog = new FogExp2(cfg.sky.horizonColor, 0.00018);
  }
}

function toggleDive() {
  underwater = !underwater;
  if (underwater) {
    camera.position.set(-120, -7, 120);
    controls.target.set(-220, -10, 0);
  } else {
    camera.position.set(120, 30, 215);
    controls.target.set(140, -2, 30);
  }
}

function onResize() {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
}

let frames = 0;
let fpsTime = 0;

function animate() {
  const dt = Math.min(clock.getDelta(), 0.05);
  const t = clock.getElapsedTime();

  if (EMBED) {
    // Low, slow drift near the surface so the waves read at the right scale.
    const a = t * 0.05;
    camera.position.set(120 + Math.sin(a) * 90, 26 + Math.sin(t * 0.2) * 5, 150 + Math.cos(a) * 90);
    camera.lookAt(120, -3, 20);
  }

  water.update(t, camera);
  buoyancy.update(dt);
  controls.update();

  if (water.submerged !== lastSubmerged) {
    lastSubmerged = water.submerged;
    const cfg = water.config;
    if (water.submerged) {
      scene.fog = new FogExp2(cfg.fog.color, cfg.fog.density);
      scene.background = new Color(cfg.fog.color);
      water.sky.visible = false;
    } else {
      scene.fog = new FogExp2(cfg.sky.horizonColor, 0.00018);
      scene.background = new Color(cfg.sky.horizonColor);
      water.sky.visible = true;
    }
  }

  renderer.render(scene, camera);

  frames++;
  fpsTime += dt;
  if (fpsTime >= 0.5) {
    const fps = frames / fpsTime;
    fpsEl.textContent = Math.round(fps) + ' fps';
    frames = 0;
    fpsTime = 0;

    // Auto-degrade: if sustained low FPS and the user hasn't pinned a level,
    // drop one quality step (never auto-upgrade — that would oscillate).
    if (autoQuality && !EMBED) {
      slowStreak = fps < 28 ? slowStreak + 1 : 0;
      const idx = QUALITY_NAMES.indexOf(water.quality);
      if (slowStreak >= 4 && idx > 0) {
        const next = QUALITY_NAMES[idx - 1];
        water.setQuality(next);
        setActiveQualityButton(next);
        slowStreak = 0;
      }
    }
  }
}

init().catch((e) => {
  console.error(e);
  statusEl.textContent = 'Error: ' + e.message;
  statusEl.style.display = 'block';
});

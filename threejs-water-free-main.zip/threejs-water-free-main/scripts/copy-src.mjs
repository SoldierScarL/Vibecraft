/**
 * Copies the library source into `docs/lib/` so the GitHub Pages demo (which can
 * only serve files under `docs/`) can import the exact same modules that npm
 * consumers get from `src/`. Run via `npm run build:docs`.
 *
 * No bundler, no transpile — the browser loads the ES modules directly; bare
 * `three` / `three/tsl` specifiers are resolved by the demo's import map.
 */
import { cp, rm, mkdir } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const src = join(root, 'src');
const dest = join(root, 'docs', 'lib');

await rm(dest, { recursive: true, force: true });
await mkdir(dest, { recursive: true });
await cp(src, dest, { recursive: true });

console.log('Copied src/ -> docs/lib/');

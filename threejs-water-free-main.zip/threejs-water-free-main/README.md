# 🌊 Three.js Water Free

**Real-time, physically-based ocean rendering for [Three.js](https://threejs.org) WebGPU.**

[![license](https://img.shields.io/badge/license-MIT-44d0dd.svg)](LICENSE)
[![three](https://img.shields.io/badge/three.js-r181%2B-2f9fcf.svg)](https://threejs.org)
[![WebGPU](https://img.shields.io/badge/WebGPU-TSL-7ff0fa.svg)](https://www.w3.org/TR/webgpu/)

Unlike noise-based water, Three.js Water Free generates the surface from a real
**FFT ocean simulation** driven by the **JONSWAP** wave spectrum — the same
oceanographic model used in offshore engineering — rendered with WebGPU and
Three.js TSL (Three Shading Language).

### ▶ [Live demo & docs](https://baditaflorin.github.io/threejs-water-free/)

---

## Features

- 🌊 **FFT-based waves** — JONSWAP spectrum, two cascades (waves + ripples), plus analytical Gerstner swells for detail at every scale.
- 💎 **Crystal-clear water** — screen-space refraction reveals the seabed; per-channel **Beer–Lambert absorption** tints it from sandy shallows to deep teal (no fake shallow/deep gradient).
- ✨ **Caustics & sparkle** — animated caustics dance on the ocean floor and refract up through the waves; high-frequency sun glitter across the surface.
- 🪸 **Dynamic foam** — Jacobian wave-crest foam plus an animated shoreline band where water meets rock and sand.
- ⚡ **WebGPU + TSL** — modern GPU pipeline; falls back to the WebGL2 backend automatically.
- 🎨 **9 environment presets** — from a serene lagoon to a violent storm, sunset, tropical, arctic and night.
- 🚢 **Buoyancy physics** — objects float on the *exact* simulated wave field, with multi-point hull support.
- 🌅 **Procedural sky** — Rayleigh-based atmosphere, animated clouds and a dynamic sun, reflected by the water.
- 🐠 **Underwater effects** — depth fog and a shimmering refracted ceiling when you dive below the surface.
- 🏝️ **Ocean floor** — a sandy seabed with caustics (`createOceanFloor`) for instant shallow-water scenes.
- 🧪 **Verifiable core** — the FFT, spectrum and wave physics are pure JS with a unit-test suite (no GPU required to test).

## Use it (no build step)

Clone the repo (or download it) and add an import map — the library loads
straight from its ES modules; `three` is a peer dependency (r181.0+, WebGPU
build). You can also point the import map at a CDN copy of the repo.

```html
<script type="importmap">
{
  "imports": {
    "three": "https://unpkg.com/three@0.181.2/build/three.webgpu.js",
    "three/webgpu": "https://unpkg.com/three@0.181.2/build/three.webgpu.js",
    "three/tsl": "https://unpkg.com/three@0.181.2/build/three.tsl.js",
    "three/addons/": "https://unpkg.com/three@0.181.2/examples/jsm/",
    "threejs-water-free": "https://cdn.jsdelivr.net/gh/baditaflorin/threejs-water-free/src/index.js"
  }
}
</script>
```

See [`examples/basic.html`](examples/basic.html) for a complete, runnable file.

## Quick start

```js
import * as THREE from 'three/webgpu';
import { Water } from 'threejs-water-free';

const renderer = new THREE.WebGPURenderer({ antialias: true });
await renderer.init();
document.body.appendChild(renderer.domElement);
renderer.setSize(innerWidth, innerHeight);

const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(60, innerWidth / innerHeight, 0.1, 12000);
camera.position.set(0, 12, 34);

// Add the ocean — one of 9 presets, or your own config.
const water = new Water({ preset: 'tropical' });
scene.add(water.object);           // adds both the sea surface and the sky dome

const clock = new THREE.Clock();
renderer.setAnimationLoop(() => {
  water.update(clock.getElapsedTime(), camera);  // advance sim & follow camera
  renderer.render(scene, camera);
});
```

> `water.object` contains the water mesh **and** the procedural sky dome. Pass
> your `camera` to `update()` so the ocean recenters on it (infinite water) and
> the underwater state is detected automatically.

## Presets

```js
new Water({ preset: 'sunset' });
```

| Name | Description |
|------|-------------|
| `lagoon` | Crystal-clear shallow turquoise |
| `calm` | Glassy, gentle swell |
| `clear` | Bright clear day, moderate chop *(default)* |
| `windy` | Brisk wind, scattered whitecaps |
| `storm` | Violent sea, heavy foam, overcast |
| `sunset` | Low warm sun, golden water |
| `tropical` | Turquoise water over sand |
| `arctic` | Cold steely sea, pale sky |
| `night` | Moonlit dark water |

## Floating objects (buoyancy)

```js
const buoyancy = water.createBuoyancy();

// Auto-samples the object's footprint, or pass explicit hull points.
buoyancy.add(boat, { offset: 0.4, damping: 3.5, alignment: 0.7 });
buoyancy.add(buoy, { offset: 0.6 });

// in your loop, after water.update():
buoyancy.update(deltaSeconds);
```

Need full rigid-body dynamics? Query the surface directly and feed your physics engine:

```js
const { height, normal } = water.getWaterInfo(x, z);
const h = water.getHeight(x, z); // height only (cheaper)
```

## Clear shallow water (ocean floor)

The clear-water look comes from the transparent surface refracting whatever is
*behind* it. Add the bundled sandy seabed with caustics and the water will
reveal it through depth-based absorption:

```js
import { createOceanFloor } from 'threejs-water-free';

const floor = createOceanFloor({
  size: 2600,
  deepDepth: 28,        // metres of open water
  beachHeight: 8,       // how high the beach rises above the surface
  timeNode: water.timeNode,       // share the water's clock so caustics animate
  preset: water.config.floor,     // sand + caustic colours from the active preset
});
scene.add(floor.mesh);
```

Any opaque geometry placed under the surface (rocks, terrain, a submarine) is
refracted and absorbed automatically — the floor is just a convenient default.

## Custom configuration

A preset is just a plain object — clone one and tweak it, or build your own.
Spectrum changes rebuild the simulation; look parameters are live uniforms.

```js
const water = new Water({
  preset: 'clear',
  resolution: 380,   // surface grid subdivisions
  extent: 8000,      // how far the sea reaches (metres)
});

water.setSun(8, 110);          // elevation, azimuth (degrees)
water.setPreset('storm');      // swap environments at runtime
```

## API

### `new Water(options)`

| option | default | description |
|--------|---------|-------------|
| `preset` | `'clear'` | preset name or a config object |
| `quality` | `'high'` | `'low'` \| `'medium'` \| `'high'` \| `'ultra'` |
| `resolution` | *(from quality)* | surface grid subdivisions (overrides the quality level) |
| `extent` | `6000` | half-size the surface reaches (m) |
| `lodPower` | `3.0` | radial LOD warp (denser near the camera) |

| member | description |
|--------|-------------|
| `.object` | `THREE.Group` (water surface + sky) — add this to your scene |
| `.update(elapsed, camera)` | advance the sim and follow the camera |
| `.getHeight(x, z)` | water surface height at world XZ |
| `.getWaterInfo(x, z)` | `{ height, normal }` at world XZ |
| `.createBuoyancy()` | a `Buoyancy` controller bound to this ocean |
| `.setSun(elevation, azimuth)` | reposition the sun (degrees) |
| `.setPreset(name)` | rebuild with another preset |
| `.setQuality(level)` | rebuild at another quality level |
| `.submerged` | `true` when the camera is below the surface |
| `.dispose()` | free GPU resources |

### Quality

One knob scales the expensive parts (FFT grid size, surface mesh density, detail
normals, sparkle). Set it at construction or switch at runtime:

```js
const water = new Water({ preset: 'tropical', quality: 'ultra' });
water.setQuality('low'); // for weak/integrated GPUs
```

| level | FFT grid | segments | detail normals | sparkle | refraction | turbulent foam | clouds |
|-------|----------|----------|:--:|:--:|:--:|:--:|:--:|
| `low` | 64² | 200 | – | – | straight | – | – |
| `medium` | 128² | 320 | ✓ | ✓ | full | – | ✓ |
| `high` | 128² | 440 | ✓ | ✓ | full | ✓ | ✓ |
| `ultra` | 256² | 600 | ✓ | ✓ | full | ✓ | ✓ |

The disabled effects are **compiled out of the shader**, not just zeroed — the
expensive FBM/texture sampling is never generated, which is what keeps the
WebGL2 fallback and integrated GPUs interactive. WebGPU is the target backend;
when it's unavailable the renderer falls back to WebGL2 and you'll typically
want `low`/`medium`. The thresholds live in the exported `QUALITY_LEVELS` —
clone it to define your own. (The demo also auto-picks a level from the backend
and steps down if the frame rate drops.)

### Advanced building blocks

These are exported for custom pipelines:

```js
import {
  Ocean, OceanCascade,        // simulation
  FFT, fft2d,                 // transform core
  buildInitialSpectrum, jonswap, dispersion, GRAVITY,
  createSky, createSkyUniforms, skyColor,
  createWaterMaterial, createOceanGeometry, createOceanFloor,
  Buoyancy, PRESETS, PRESET_NAMES, QUALITY_LEVELS,
} from 'threejs-water-free';
```

## How it works

1. **Spectrum** — `buildInitialSpectrum()` samples the JONSWAP energy spectrum with a cosine² directional spread, maps it into the wave-number domain via the deep-water dispersion relation, and seeds it with complex Gaussian noise (Tessendorf). The field is normalised so the realised significant wave height matches the requested value.
2. **Evolution** — each frame the spectrum is advanced in time and **inverse-FFT'd** to a height field, a horizontal (choppy) displacement field and a slope field. A packing trick recovers two real fields per complex transform.
3. **Foam** — the Jacobian of the displacement map detects wave folding/breaking; crest foam is added by height threshold, and a depth-gated, noise-broken band adds shoreline foam.
4. **Cascades + swell** — two FFT bands (large waves + fine ripples) at different tile sizes combine with a handful of analytical Gerstner swell waves for long-period motion.
5. **Refraction & colour** — the surface is transparent. It reads the depth buffer to find the water-column depth, samples the scene behind it (`viewportSharedTexture`) offset by the wave normal for refraction, then applies **per-channel Beer–Lambert absorption** `exp(−extinction·depth)` to blend the refracted seabed toward the intrinsic water colour.
6. **Shading** — the wave normal (perturbed by an animated detail-normal and flattened with distance) drives a Schlick/IOR **Fresnel** blend between the refracted water body and the reflected procedural sky, plus subsurface scattering, a sun specular and sparse sun glitter. Reflections reuse the very same `skyColor()` as the sky dome.

The simulation runs on the CPU (fully deterministic and unit-tested) and uploads
displacement/slope textures to the GPU, so the physics you query for buoyancy is
exactly the water you see.

## Requirements

- **Three.js r181.0+** — the WebGPU build (`three/webgpu`) with TSL.
- **A WebGPU browser** — Chrome 113+, Edge 113+, or Firefox Nightly. Automatically falls back to the WebGL2 backend.
- **ES2020+ modules.**

## Development

```bash
npm test            # run the FFT + simulation test suites (pure Node, no GPU)
npm run dev         # serve docs/ at http://localhost:5173
npm run build:docs  # copy src/ into docs/lib/ for the Pages demo
```

The interactive demo lives in [`docs/demo/`](docs/demo/) and the landing page in
[`docs/index.html`](docs/index.html); GitHub Pages serves the `docs/` folder.

## License

[MIT](LICENSE) © 2026 Florin Badita

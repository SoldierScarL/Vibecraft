/**
 * Tests for the FFT core. Run with: `node test/fft.test.mjs`
 * No external dependencies — pure Node.
 */
import { FFT, fft2d } from '../src/core/fft.js';

let passed = 0;
let failed = 0;

function check(name, cond, detail = '') {
  if (cond) {
    passed++;
    console.log(`  ✓ ${name}`);
  } else {
    failed++;
    console.error(`  ✗ ${name} ${detail}`);
  }
}

function maxAbsDiff(a, b) {
  let m = 0;
  for (let i = 0; i < a.length; i++) m = Math.max(m, Math.abs(a[i] - b[i]));
  return m;
}

// Reference O(n^2) DFT for cross-checking the fast transform.
function naiveDFT(re, im, inverse = false) {
  const n = re.length;
  const outR = new Float32Array(n);
  const outI = new Float32Array(n);
  const sign = inverse ? 1 : -1;
  for (let k = 0; k < n; k++) {
    let sr = 0;
    let si = 0;
    for (let t = 0; t < n; t++) {
      const a = (sign * 2 * Math.PI * k * t) / n;
      const c = Math.cos(a);
      const s = Math.sin(a);
      sr += re[t] * c - im[t] * s;
      si += re[t] * s + im[t] * c;
    }
    if (inverse) {
      sr /= n;
      si /= n;
    }
    outR[k] = sr;
    outI[k] = si;
  }
  return { outR, outI };
}

console.log('FFT vs naive DFT (forward), n=8,16,32,64:');
for (const n of [8, 16, 32, 64]) {
  const re = new Float32Array(n);
  const im = new Float32Array(n);
  for (let i = 0; i < n; i++) {
    re[i] = Math.sin(i * 0.7) + 0.3 * i;
    im[i] = Math.cos(i * 1.3) - 0.1 * i;
  }
  const ref = naiveDFT(re, im, false);
  const fft = new FFT(n);
  const fr = re.slice();
  const fi = im.slice();
  fft.transform(fr, fi, false);
  const err = Math.max(maxAbsDiff(fr, ref.outR), maxAbsDiff(fi, ref.outI));
  check(`n=${n} forward matches DFT`, err < 1e-3, `(maxdiff=${err})`);
}

console.log('Inverse(Forward(x)) == x:');
for (const n of [8, 64, 256, 1024]) {
  const re = new Float32Array(n);
  const im = new Float32Array(n);
  for (let i = 0; i < n; i++) {
    re[i] = Math.sin(i * 0.123) * 5 - 2;
    im[i] = Math.cos(i * 0.077) * 3;
  }
  const r0 = re.slice();
  const i0 = im.slice();
  const fft = new FFT(n);
  fft.transform(re, im, false);
  fft.transform(re, im, true);
  const err = Math.max(maxAbsDiff(re, r0), maxAbsDiff(im, i0));
  check(`n=${n} round-trip`, err < 1e-3, `(maxdiff=${err})`);
}

console.log('Real input -> Hermitian-symmetric spectrum:');
{
  const n = 32;
  const re = new Float32Array(n);
  const im = new Float32Array(n);
  for (let i = 0; i < n; i++) re[i] = Math.sin(i * 0.9) + 2;
  const fft = new FFT(n);
  fft.transform(re, im, false);
  // X[k] should equal conj(X[n-k])
  let err = 0;
  for (let k = 1; k < n; k++) {
    err = Math.max(err, Math.abs(re[k] - re[n - k]));
    err = Math.max(err, Math.abs(im[k] + im[n - k]));
  }
  check('Hermitian symmetry', err < 1e-3, `(err=${err})`);
}

console.log("Parseval's theorem (energy preserved):");
{
  const n = 128;
  const re = new Float32Array(n);
  const im = new Float32Array(n);
  for (let i = 0; i < n; i++) {
    re[i] = Math.sin(i * 0.31) * 1.7;
    im[i] = Math.cos(i * 0.13) * 0.6;
  }
  let timeEnergy = 0;
  for (let i = 0; i < n; i++) timeEnergy += re[i] * re[i] + im[i] * im[i];
  const fft = new FFT(n);
  fft.transform(re, im, false);
  let freqEnergy = 0;
  for (let i = 0; i < n; i++) freqEnergy += re[i] * re[i] + im[i] * im[i];
  freqEnergy /= n; // Parseval: sum|X|^2 = n * sum|x|^2
  const rel = Math.abs(timeEnergy - freqEnergy) / timeEnergy;
  check('Parseval', rel < 1e-4, `(rel err=${rel})`);
}

console.log('2-D round-trip (n=64):');
{
  const n = 64;
  const re = new Float32Array(n * n);
  const im = new Float32Array(n * n);
  for (let i = 0; i < n * n; i++) {
    re[i] = Math.sin(i * 0.017) + (i % 7);
    im[i] = Math.cos(i * 0.029);
  }
  const r0 = re.slice();
  const i0 = im.slice();
  fft2d(re, im, n, false);
  fft2d(re, im, n, true);
  const err = Math.max(maxAbsDiff(re, r0), maxAbsDiff(im, i0));
  check('2-D round-trip', err < 1e-2, `(maxdiff=${err})`);
}

console.log('Linearity FFT(a·x + b·y) == a·FFT(x) + b·FFT(y):');
{
  const n = 64;
  const a = 1.7;
  const b = -0.4;
  const xr = new Float32Array(n);
  const yr = new Float32Array(n);
  const zero = new Float32Array(n);
  for (let i = 0; i < n; i++) {
    xr[i] = Math.sin(i * 0.5);
    yr[i] = Math.cos(i * 0.2);
  }
  const fft = new FFT(n);
  const Xr = xr.slice();
  const Xi = zero.slice();
  fft.transform(Xr, Xi, false);
  const Yr = yr.slice();
  const Yi = zero.slice();
  fft.transform(Yr, Yi, false);
  const combo = new Float32Array(n);
  const comboI = new Float32Array(n);
  for (let i = 0; i < n; i++) combo[i] = a * xr[i] + b * yr[i];
  fft.transform(combo, comboI, false);
  let err = 0;
  for (let i = 0; i < n; i++) {
    err = Math.max(err, Math.abs(combo[i] - (a * Xr[i] + b * Yr[i])));
    err = Math.max(err, Math.abs(comboI[i] - (a * Xi[i] + b * Yi[i])));
  }
  check('linearity', err < 1e-3, `(err=${err})`);
}

console.log('Throws on non-power-of-two:');
{
  let threw = false;
  try {
    new FFT(48);
  } catch {
    threw = true;
  }
  check('rejects n=48', threw);
}

console.log(`\n${passed} passed, ${failed} failed`);
process.exit(failed === 0 ? 0 : 1);

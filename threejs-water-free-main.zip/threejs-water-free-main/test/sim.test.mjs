/**
 * Validates the wave simulation physics. Run: `node test/sim.test.mjs`
 * Only depends on the pure-JS core (no Three.js / GPU).
 */
import { OceanCascade } from '../src/core/cascade.js';
import { buildInitialSpectrum, jonswap, GRAVITY } from '../src/core/spectrum.js';

let passed = 0;
let failed = 0;
const check = (name, cond, detail = '') => {
  if (cond) {
    passed++;
    console.log(`  ✓ ${name}`);
  } else {
    failed++;
    console.error(`  ✗ ${name} ${detail}`);
  }
};

const baseParams = {
  size: 128,
  patchSize: 200,
  windSpeed: 12,
  windDir: 0.6,
  fetch: 80000,
  gamma: 3.3,
  waveHeight: 3.0,
  shortWaves: 0.5,
  seed: 1234,
};

console.log('JONSWAP spectrum shape:');
{
  const omegaP = 22 * Math.pow((GRAVITY * GRAVITY) / (12 * 80000), 1 / 3);
  const alpha = 0.076 * Math.pow((12 * 12) / (GRAVITY * 80000), 0.22);
  const atPeak = jonswap(omegaP, omegaP, alpha, 3.3);
  const below = jonswap(omegaP * 0.5, omegaP, alpha, 3.3);
  const above = jonswap(omegaP * 2.0, omegaP, alpha, 3.3);
  check('peak is the maximum', atPeak > below && atPeak > above, `(peak=${atPeak.toExponential(2)})`);
  check('S(ω<=0) == 0', jonswap(0, omegaP, alpha, 3.3) === 0);
}

console.log('Cascade synthesis:');
{
  const c = new OceanCascade({ ...baseParams });
  c.update(3.7);
  const N = c.size;

  // Significant wave height ≈ requested waveHeight.
  let sum = 0;
  let sumSq = 0;
  let minFoam = Infinity;
  for (let i = 0; i < N * N; i++) {
    const h = c.displacement[i * 4 + 1];
    sum += h;
    sumSq += h * h;
    minFoam = Math.min(minFoam, c.displacement[i * 4 + 3]);
  }
  const mean = sum / (N * N);
  const rms = Math.sqrt(sumSq / (N * N));
  const hs = 4 * rms;
  check('mean height ≈ 0', Math.abs(mean) < 0.05, `(mean=${mean.toFixed(4)})`);
  check(
    'significant wave height ≈ requested',
    Math.abs(hs - baseParams.waveHeight) / baseParams.waveHeight < 0.25,
    `(Hs=${hs.toFixed(3)}, want≈${baseParams.waveHeight})`
  );
  check('foam is non-negative', minFoam >= 0, `(min=${minFoam})`);

  // Finite values only.
  let allFinite = true;
  for (let i = 0; i < N * N * 4; i++) {
    if (!Number.isFinite(c.displacement[i]) || !Number.isFinite(c.slope[i])) {
      allFinite = false;
      break;
    }
  }
  check('all field values finite', allFinite);
}

console.log('Determinism (same seed -> identical field):');
{
  const a = new OceanCascade({ ...baseParams });
  const b = new OceanCascade({ ...baseParams });
  a.update(2.0);
  b.update(2.0);
  let maxDiff = 0;
  for (let i = 0; i < a.displacement.length; i++) {
    maxDiff = Math.max(maxDiff, Math.abs(a.displacement[i] - b.displacement[i]));
  }
  check('identical for same seed', maxDiff === 0, `(maxDiff=${maxDiff})`);

  const cdiff = new OceanCascade({ ...baseParams, seed: 9999 });
  cdiff.update(2.0);
  let differs = false;
  for (let i = 0; i < a.displacement.length; i++) {
    if (Math.abs(a.displacement[i] - cdiff.displacement[i]) > 1e-6) {
      differs = true;
      break;
    }
  }
  check('different for different seed', differs);
}

console.log('Time evolution (field changes over time):');
{
  const c = new OceanCascade({ ...baseParams });
  c.update(0);
  const snap = c.displacement.slice();
  c.update(1.5);
  let moved = 0;
  for (let i = 0; i < snap.length; i++) moved += Math.abs(snap[i] - c.displacement[i]);
  check('waves move in time', moved > 1, `(total delta=${moved.toFixed(1)})`);
}

console.log('Initial spectrum sanity:');
{
  const s = buildInitialSpectrum({ ...baseParams });
  check('DC component is zero', s.h0[(64 * 128 + 64) * 2] === 0 && s.h0[(64 * 128 + 64) * 2 + 1] === 0);
  let energy = 0;
  for (let i = 0; i < s.h0.length; i++) energy += s.h0[i] * s.h0[i];
  check('spectrum has energy', energy > 0, `(energy=${energy.toExponential(2)})`);
}

console.log(`\n${passed} passed, ${failed} failed`);
process.exit(failed === 0 ? 0 : 1);
